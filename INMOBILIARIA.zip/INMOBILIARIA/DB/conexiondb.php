<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "inmobiliaria_db";

$pdo = new PDO("mysql:host=$host;dbname=$database", $user, $password);
