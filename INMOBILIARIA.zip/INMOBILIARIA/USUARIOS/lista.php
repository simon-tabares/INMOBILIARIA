<?php
include("../DB/conexiondb.php");

$sql = "SELECT * FROM usuario";
$result = $pdo->query($sql);
$usuarios = $result->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../estilos.css" />
</head>
<body>
    <h1>Usuarios</h1>
    <a href="crear.php"> <button>Crear usuario</button></a>
    <table border=1>
        <tr>
            <td>ID</td>
            <td>Nombre</td>
            <td>Correo</td>
            <td>Telefono</td>
            <td>Rol</td>
            <td>Fecha de Registro</td>
        </tr>
        <?php foreach($usuarios as $u): ?>
            <tr>
            <td><?= $u["id_usuario"] ?></td>
            <td><?= $u["nombre"] ?></td>
            <td><?= $u["correo"] ?></td>
            <td><?= $u["telefono"] ?></td>
            <td><?= $u["rol"] ?></td>
            <td><?= $u["fecha_registro"] ?></td>
            <td>
                <form action="Actualizar.php" method="post">
                    <input type="hidden" name="id_usuario" value="<?=$u['id_usuario'] ?>">
                    <input type="submit" value="Editar">
                </form>
                <form action="eliminar.php" method="post">
                    <input type="hidden" name="id_usuario" value="<?= $u['id_usuario'] ?>">
                    <input type="submit" value="Eliminar">
                </form>
            </td>
            </tr>
        <?php endforeach; ?>
    </table>

</body>
</html>