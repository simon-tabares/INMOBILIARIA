<?php 

include("../DB/conexiondb.php");

if($_POST) {
    $sql = "INSERT INTO usuario
    (nombre, correo, contraseña, telefono, direccion, rol)
    VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$_POST["Nombre"],
                    $_POST["Correo"],
                    $_POST["Contrasena"],
                    $_POST["Telefono"],
                    $_POST["direccion"],
                    $_POST["rol"]]);
    
    
}
header("locacation: ../index.php");