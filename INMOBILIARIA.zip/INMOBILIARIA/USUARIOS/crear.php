<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../estilo.css" />
    <style>
form {
    max-width: 400px;
    margin: 40px auto;
    background-color: #f5f0e6;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
}

label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: #333;
}

input {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
    transition: border 0.3s;
}

input:focus {
    border-color: #3498db;
    outline: none;
}

button {
    width: 100%;
    padding: 12px;
    background-color: #e7a41d;
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background-color: #0f0e0c;
}
</style>
</head>
<body>
    <form action="procesoCrear.php" method="POST">
        <label for="nombre">NOMBRE</label>
        <input type="text" id="Nombre" name="Nombre" required><br><br>
        
        <label for="Correo">CORREO</label>
        <input type="email" id="Correo" name="Correo" required><br><br>

        <label for="Contrasena">CONTRASEÑA</label>
        <input type="password" id="Contrasena" name="Contrasena" required><br><br>

        <label for="Telefono">TELEFONO</label>
        <input type="number" id="Telefono" name="Telefono" required><br><br>

        <label for="direccion"> DIRECCION</label>
        <input type="text" id="direccion" name="direccion" required><br><br>

        <label for="rol">ROL</label>
        <input type="text" id="rol" name="rol" required><br><br>

        <button type="submit">Crear Usuario</button>
    </form>
</body>
</html>