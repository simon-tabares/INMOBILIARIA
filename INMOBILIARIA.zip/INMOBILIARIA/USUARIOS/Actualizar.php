<?php
include("../DB/conexiondb.php");

if (!isset($_POST['id']) || empty($_POST['id']) || !is_numeric($_POST['id'])) {
    die("ID de usuario no válido.");
}

$id = $_POST['id'];

$sql = "SELECT * FROM usuario WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);


if (!$usuario) {
    die("Usuario no encontrado.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario</title>
    <link rel="stylesheet" href="../estilo.css" />
    <style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #2c230b, #92805e);
    margin: 0;
    padding: 0;
}

form {
    max-width: 420px;
    margin: 60px auto;
    background: #f5f0e6;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0px 8px 25px rgba(0,0,0,0.2);
    animation: aparecer 0.5s ease;
}

@keyframes aparecer {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #333;
}

label {
    font-weight: 600;
    display: block;
    margin-bottom: 5px;
    color: #555;
}

input {
    width: 100%;
    padding: 12px;
    margin-bottom: 15px;
    border-radius: 8px;
    border: 1px solid #ccc;
    transition: 0.3s;
    font-size: 14px;
}

input:focus {
    border-color: #667eea;
    box-shadow: 0px 0px 5px rgba(102,126,234,0.5);
    outline: none;
}

small {
    display: block;
    margin-top: -10px;
    margin-bottom: 15px;
    color: #888;
}

button {
    width: 100%;
    padding: 12px;
    background: #f0c671;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: 0.3s;
}

button:hover {
    background: #090806;
}

</style>
</head>
<body>
    <form action="proceso_actualizacion.php" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($id) ?>">

        <label for="nombre">NOMBRE</label>
        <input type="text" id="nombre" name="nombre" 
               value="<?= htmlspecialchars($usuario['nombre']) ?>" required><br><br>

        <label for="correo">CORREO</label>
        <input type="email" id="correo" name="correo" 
               value="<?= htmlspecialchars($usuario['correo']) ?>" required><br><br>

        <label for="contraseña">CONTRASEÑA</label>
        <input type="password" id="Contraseña" name="contraseña" 
               value="<?= htmlspecialchars($usuario['contraseña']) ?>" required><br><br>

        <label for="telefono">TELEFONO</label>
        <input type="number" id="telefono" name="telefono" 
               value="<?= htmlspecialchars($usuario['telefono']) ?>" required><br><br>

       <label for="direccion">DIRECCION</label>
        <input type="text" id="direccion" name="direccion" 
               value="<?= htmlspecialchars($usuario['direccion']) ?>" required><br><br>

        <label for="rol">ROL</label>
        <input type="text" id="rol" name="rol" 
               value="<?= htmlspecialchars($usuario['rol']) ?>" required><br><br>
               
        <button type="submit">Actualizar Usuario</button>
    </form>
</body>
</html>