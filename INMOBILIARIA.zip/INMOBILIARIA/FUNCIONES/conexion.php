<?php
    session_start();
    if(isset($_SESSION[' usuario' ])){
        header ("Location: ../index.php");
    }

    function conectar(){
        $host = "localhost";
        $user = "root";
        $pass = "*";
        $db = "banco_app";
        $conn = new mysqli($host, $user, $pass, $db);
        if ($conn->connect_error){
            die("Connection failed: " . $conn->connect_error);
}
return $conn;
}
?>