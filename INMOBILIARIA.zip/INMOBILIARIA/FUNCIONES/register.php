<?php
include 'conexion.php';

$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$password = $_POST['password'];
$id_role = $_POST["rol"];

function register($nombre, $correo, $password, $id_role){
    $password = password_hash($password, PASSWORD_DEFAULT);
    $conn = conectar();
    $stmt = $conn->prepare("INSERT INTO usuarios (nombre, correo, contrasenia, id_rol) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("", $nombre, $correo, $password, $id_role);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    header("Location: ../admin/index.php");
}

register($nombre, $correo, $password, $id_role);
?>