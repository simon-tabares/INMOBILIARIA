<?php
include 'conexion.php';
$email = $_POST['email'];
$contrasenia = $_POST['contrasena'];

function login($email, $contrasena){
    $conn = conectar();
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE correo = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if($result->num_rows > 0){
        $user = $result->fetch_assoc();
        if(password_verify($contrasenia, $user['contrasena'])){
            $_SESSION['usuario'] = $user;
            header("Location: ../admin/index.php");
        }
    }
    $stmt->close();
    $conn->close();
}

login($email, $contrasenia);
?>