<head>
  <title>menu</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="estilos.css">
</head>
<nav>
    <div class="menu-logo"> INMOBILIARIA</div>

    <div class="menu-principal">
    <a href="index.php">◆ Inicio</a>
    <a href="contacto.php">✦ Contacto</a>
    <div class="menu-logo"> PROPIEDADES</div>
    <a href="PROPIEDADES/arquiler.php">⌂ ARQUILER</a>
    <a href="PROPIEDADES/venta.php">⌂ VENTA</a>
    </div>

    <div class="menu-cuenta">
    
    <a href="login.php"> Iniciar Sesión</a>
    <a href="register.php"> Registro</a>
    <a href="usuarios/lista.php"> Usuarios</a>
    </div>
</nav>
