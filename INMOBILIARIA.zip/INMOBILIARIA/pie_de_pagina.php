<footer>
    <p>&copy; 2026 MI INMOBILIARIA. Todos los derechos reservados.</p>
<footer>