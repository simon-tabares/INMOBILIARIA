<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title> Document</title> 
    <link rel="stylesheet" href="../css/estilos.css">
    <style>
table{
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    background: white;
    box-shadow: 0 2px 10px rgba(0,0,0,.1);
}

th{
    background: #665623;
    color: white;
    padding: 12px;
}

td{
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

tr:hover{
    background: #f5f5f5;
}
</style>
</head>
<body>
    <div class="container">
        <div class="admin-layout">
            <?php include 'sidebar.php'; ?> 
            <div class="contenedor Interno admin-content">
                <h1> Creditos</h1>
                <p>Administra tus creditos con facilidad.</p>
                <table>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email</th>
                        <th>Telefono</th>
                        <th>Direccion</th>
                        <th>Ciudad</th>
                        <th>Estado</th>
                        <th>Codigo Postal</th>
                        <th>Pais</th>
                        <th>Contraseña</th>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</body> 
</html>