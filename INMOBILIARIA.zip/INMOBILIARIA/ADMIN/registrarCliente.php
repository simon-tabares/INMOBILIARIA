<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Document</title>
    <link rel-"stylesheet" href="../estilos.css">
    <style>
.contenedorInterno{
    max-width: 700px;
    margin: 30px auto;
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,.1);
}

form input{
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 6px;
}

form input[type="submit"]{
    background: #665623;
    color: white;
    border: none;
    cursor: pointer;
    font-size: 16px;
}

form input[type="submit"]:hover{
    background: #665623;
}
</style>
</head>
<body>
    <div class="container">
        <div class-"admin-layout">
            <div class="contenedorInterno admin-content">
                <h1>Registrar Cliente</h1>
                <p>Registra a tus clientes con facilidad.</p>
                <form action="registrarCliente-php" method="post">
                    <label for="nombre">Nombre:</label><br>
                    <input type="text" id="nombre" name="nombre" required><br><br>
                    <label for="apellido">Apellido:</label><br>
                    <input type="text" id="apellido" name="apellido" required><br><br>
                    <label for="email">Email:</label><br>
                    <input type="email" id="email" name="email" required><br><br>
                    <label for="telefono">Telefono: </label><br>
                    <input type="text" id="telefono" name="telefono" required><br><br>
                    <label for="direccion">Direccion: </label><br>
                    <input type="text" id="direccion" name="direccion" required><br><br>
                    <label for="ciudad">Ciudad: </label><br>
                    <input type="text" id="ciudad" name="ciudad" required><br><br>
                    <label for="estado">Estado: </label><br>
                    <input type="text" id="estado" name="estado" required><br><br>
                    <label for="codigoPostal">Codigo Postal:</label><br>
                    <input type="text" id="codigoPostal" name-"codigoPostal" required><br><br>
                    <label for="password">Contraseña: </label><br>
                    <input type="password" id="password" name-"password" required><br><br>
                    <input type="submit" value="Registrarse">
                </form>
            </div>
        </div>
    </div>
</body> 
</html>