<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/estilos.css">
    <style>
body{
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #f4f6f9;
}

.container{
    width: 100%;
    min-height: 100vh;
}

.admin-layout{
    display: flex;
}

.contenedorInterno{
    flex: 1;
    margin: 30px;
    padding: 30px;
    background: white;
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

h1{
    color: #665623;
    margin-bottom: 10px;
}

p{
    color: #666;
    margin-bottom: 25px;
}

form{
    display: flex;
    flex-direction: column;
    gap: 15px;
}

label{
    font-weight: bold;
    color: #333;
}

input,
select{
    width: 100%;
    padding: 12px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-size: 15px;
    outline: none;
    transition: 0.3s;
}

input:focus,
select:focus{
    border-color: #665623;
    box-shadow: 0 0 5px rgba(37,99,235,0.3);
}

input[type="submit"]{
    background: #665623;
    color: white;
    border: none;
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
    padding: 14px;
}

input[type="submit"]:hover{
    background: #d88d1d;
}

@media(max-width: 768px){
    .contenedorInterno{
        margin: 15px;
        padding: 20px;
    }
}
</style>
</head>
<body>
    <div class="container">
        <div class="admin-layout">
            <?php include 'sidebar.php'; ?> 
            <div class="contenedor Interno admin-content">
                <h1>Solicitud de Credito</h1>
                <p>Administra tus creditos con facilidad.</p>
                <form action="solicitudCredito.php" method="post">
                    Selecciona el tipo de credito:
                    <select name="tipoCredito" id="tipoCredito">
                        <option value="personal">Personal</option>
                        <option value="hipoteca">Hipoteca</option>
                        <option value="auto">Auto</option>
                    </select>
                    <select name="usuario" id="usuario">
                        <option value="idUsuario">Usuario 1</option> 
                        <option value="idUsuario">Usuario 2</option>
                    </select>
                    <input type="number" name="monto" id="monto" placeholder="Monto">
                    <input type="number" name="interes" id="interes" placeholder="Interes">
                    <input type="number" name="plazo" id="plazo" placeholder="Plazo">
                    <input type="submit" value="Enviar">
                </form>
            </div>
        </div>
    </div>
</body> 
</html>