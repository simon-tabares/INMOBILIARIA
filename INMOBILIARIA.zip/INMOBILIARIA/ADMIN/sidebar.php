<aside class="sidebar">
    <head>
        <style>
.sidebar{
    width: 250px;
    min-height: 100vh;
    background: #665623;
    color: white;
    padding-top: 20px;
}

.sidebar-header{
    text-align: center;
    font-size: 22px;
    font-weight: bold;
    padding: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.2);
}

.sidebar-nav{
    display: flex;
    flex-direction: column;
    padding: 15px;
}

.sidebar-nav a{
    text-decoration: none;
    color: white;
    padding: 12px 15px;
    margin: 5px 0;
    border-radius: 8px;
    transition: 0.3s;
}

.sidebar-nav a:hover{
    background: #665623;
    transform: translateX(5px);
}

.sidebar-nav hr{
    border: none;
    border-top: 1px solid rgba(255,255,255,0.2);
    margin: 15px 0;
}

.admin-layout{
    display: flex;
    min-height: 100vh;
}

.admin-content{
    flex: 1;
    padding: 30px;
    background: #f4f6f9;
}
</style>
</head>
    <div class="sidebar-header">Administración</div>
    <nav class="sidebar-nav">
        <a href="usuarios.php">Usuarios</a>
        <a href="registrarCliente.php">Registrar Cliente</a>
        <a href="creditos.php">Créditos</a>
        <a href="solicitudCredito.php">Solicitud de Crédito</a>
        <hr>
        <a href="../index.php">Volver al sitio</a>
    </nav>
</aside>