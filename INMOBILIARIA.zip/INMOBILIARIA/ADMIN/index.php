<!DOCTYPE html >
<html lang="en" >
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Admin</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head> 
<body>
    <div class="container">
        <div class="admin-layout">
            <?php include 'sidebar.php'; ?>
            <div class="contenedorInterno admin-content">
                <h1>Panel de Administracion</h1>
                <p>Administra tus servicios bancarios con facilidad.</p>
            </div>
        </div>
    </div>
</body>
</html>