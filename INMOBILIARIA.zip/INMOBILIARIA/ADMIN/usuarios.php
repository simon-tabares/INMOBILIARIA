<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale-1.0"> 
    <title>Document</title>
    <link rel="stylesheet" href="../css/estilos.css">
    <style>   
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, Helvetica, sans-serif;
}

body{
    background: #f4f6f9;
    color: #333;
}

.container{
    width: 100%;
    padding: 20px;
}

.contenedorInterno{
    background: #fff;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

h1{
    color: #665623;
    margin-bottom: 10px;
}

p{
    margin-bottom: 20px;
    color: #6b7280;
}

a button{
    background: #665623;
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 8px;
    cursor: pointer;
    margin-bottom: 20px;
    font-size: 15px;
    transition: 0.3s;
}

a button:hover{
    background: #665623;
}

table{
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
    background: white;
    border-radius: 10px;
    overflow: hidden;
}

table th{
    background: #665623;
    color: white;
    padding: 15px;
    text-align: left;
}

table td{
    padding: 12px;
    border-bottom: 1px solid #e5e7eb;
}

table tr:nth-child(even){
    background: #f9fafb;
}

table tr:hover{
    background: #e0f2fe;
    transition: 0.3s;
}
</style>
    
</head>
<body >
    <div class-"container">
        <div class="admin-layout">
            <?php include 'sidebar.php'; ?>
            <div class="contenedorInterno admin-content">
                <h1> Usuarios</h1>
                <p>Administra tus servicios bancarios con facilidad.</p>
                <a href="registrarCliente.php"><button>Registrar Cliente</button></a>
                <table>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email</th>
                        <th>Telefono</th>
                        <th>Direccion</th>
                        <th>Ciudad</th>
                        <th>Estado</th>
                        <th>Codigo Postal</th>
                        <th>Pais</th>
                        <th>Contrasena</th>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</body>
</html>