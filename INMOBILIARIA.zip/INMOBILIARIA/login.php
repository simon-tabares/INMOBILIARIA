<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="estilos.css">

</head>

<body class="login-page">
    <div class="container">
        <div class="contenedorInterno">
            <h1>Iniciar Sesión</h1>
            <form action="admin/index.php" method="post">
                <label for="username">Usuario:</label>
                <input type="text" id="username" name="username" required>

                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>

                <input type="submit" value="Iniciar Sesión">
            </form>
        </div>
    </div>
</body>
</html>