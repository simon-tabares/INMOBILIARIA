<!DOCTYPE html>
<html lang="en">
<head>
  <title>INMOBILIARIA</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="estilos.css">
</head>
<body>

<div class="container-fluid p-5 bg-dark text-white text-center">
  <h1>INMOBILIARIA</h1>
  <p>"Aca encontraras la propiedad de tus sueños"</p> 
</div>
  <?php include "menu.php"; ?>
<div class="container mt-5">
  <div class="row">
    <div class="col-sm-4">
      <h2>COMPRA DE PROPIEDADES</h2>
      <p>Encuentra casas y apartamentos en las mejores zonas de la ciudad.</p>
    </div>
    <div class="col-sm-4">
      <h2>ARRIENDO FACIL</h2>
      <p>Explora opciones de arriendo seguras y al mejor precio.</p>
    </div>
    <div class="col-sm-4">
      <h2>ASESORIA INMOBILIARIA</h2>
      <p>Te ayudamos a tomar la mejor decisión para invertir en vivienda.</p>
    </div>
  </div>
  <?php include "pie_de_pagina.php" ; ?>
</div>

</body>
</html>
